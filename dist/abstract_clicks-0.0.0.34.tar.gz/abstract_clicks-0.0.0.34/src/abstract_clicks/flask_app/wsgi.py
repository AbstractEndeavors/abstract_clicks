from getRecieve import getRecieve_app
app = getRecieve_app()

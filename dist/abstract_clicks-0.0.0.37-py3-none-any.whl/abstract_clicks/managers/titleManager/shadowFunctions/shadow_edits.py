from .shadow_main import *
def load_titles():
    return titlemanager.load_titles()

def save_titles():
    return titlemanager.save_titles()

def delete_title(title):
    return titlemanager.delete_title(title=title)


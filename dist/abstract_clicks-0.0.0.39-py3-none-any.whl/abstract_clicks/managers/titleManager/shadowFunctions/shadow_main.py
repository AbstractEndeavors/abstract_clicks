from ..titleManager import get_titlemanager
titlemanager = get_titlemanager()



from ..managers.clipboardManager import get_clipboard
clipboard = get_clipboard()

from .shadow_main import *
def get_window_info(url=None, title=None, browser_title=None):
    return titlemanager.get_window_info(url=url, title=title, browser_title=browser_title)

